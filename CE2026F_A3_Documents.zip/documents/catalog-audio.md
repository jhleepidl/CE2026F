# PocketBeat speaker: aliases, battery, and compatible accessories

Document ID: catalog-audio
Source: official
Effective: 2026-01-01 to open-ended
Related: shipping, warranty, stock

PocketBeat Mini is also called PB-M or the travel speaker. It contains a rechargeable lithium battery and charges over USB-C. A charging cable is included; a wall adapter is not included. The C20 USB-C wall adapter is compatible. The old barrel-plug A12 adapter is not compatible. The product's compact size does not remove shipping restrictions.
The speaker has a six-month manufacturing-fault warranty. Accidental liquid damage is excluded. Product specifications describe compatibility and included items; they do not state current stock. Check the shipping policy before promising delivery to the Island region.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
