# Order LH-733: standard SteamDrop K2 purchase

Document ID: order-733
Source: official
Effective: 2026-01-01 to open-ended
Related: returns

Order LH-733 is an ordinary SteamDrop K2 kettle, bought through the standard shop and delivered September 10, 2026. It is unused, not personalized, and working. The buyer has the order number and wishes to return it because the colour does not match the kitchen.
There is no recorded defect or outlet classification. Use the standard change-of-mind policy, including the return-label fee and refund method. The buyer's colour preference does not create a faulty-arrival exception. The original payment card is still active.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
