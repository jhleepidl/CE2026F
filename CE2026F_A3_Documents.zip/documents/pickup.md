# Collection and pickup: general branch procedure

Document ID: pickup
Source: official
Effective: 2026-01-01 to open-ended
Related: harbor-notice, hill-notice

A ready-for-collection email is required before pickup. Bring the order number and photo ID. A different adult may collect with the named buyer's written authorization, their own photo ID, and the order number. A shipping notification alone does not mean the order is ready for pickup.
Harbor normally offers pickup from 09:00 to 18:00; Hill normally offers pickup from 10:00 to 19:00. Temporary branch notices override these regular hours. An order is held for seven calendar days after the ready email. Do not transfer an order to another branch or promise a hold extension without a documented instruction.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
