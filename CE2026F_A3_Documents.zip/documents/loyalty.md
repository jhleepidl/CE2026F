# LumaPoints loyalty credits

Document ID: loyalty
Source: official
Effective: 2026-01-01 to open-ended
Related: 

Members earn one LumaPoint for each dollar spent on merchandise, excluding shipping, wrapping, and taxes. Points become available after the ordinary return window. Refunded merchandise reverses its corresponding points. Points cannot be exchanged for cash or transferred between accounts.
Loyalty membership does not extend outlet return deadlines or override personalization exclusions. Support agents should not promise a points balance without an account record. This document describes the programme rules, not the current balance of any named customer.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
