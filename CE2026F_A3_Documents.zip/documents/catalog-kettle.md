# SteamDrop kettle: versions and maintenance

Document ID: catalog-kettle
Source: official
Effective: 2026-01-01 to open-ended
Related: stock, warranty

SteamDrop K2 is the current 1.2-litre electric kettle, also called the compact kettle. Its replaceable filter is F2. The older SteamDrop K1 uses filter F1; the filters are not interchangeable. The product label under the base identifies the version. K2 is compatible with the B2 base and not the B1 base.
Unplug the kettle before cleaning and follow its supplied manual. This product entry provides only product identifiers and compatibility for customer support; it does not authorize repairs. Replacement-part stock varies and is not provided by this catalogue. A customer who does not know the version needs to check the label before choosing a filter.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
