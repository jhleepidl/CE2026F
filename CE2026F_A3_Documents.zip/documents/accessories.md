# Replacement accessories and product versions

Document ID: accessories
Source: official
Effective: 2026-01-01 to open-ended
Related: catalog-kettle, catalog-audio, stock

Match replacement accessories to the exact product version. SteamDrop K1 takes F1 filters and B1 bases; SteamDrop K2 takes F2 filters and B2 bases. PocketBeat Mini uses a USB-C cable and can use the C20 adapter. A12 barrel-plug adapters cannot connect to PocketBeat Mini.
Compatibility does not establish availability. A replacement part can be compatible and still be out of stock. The support collection has no live inventory feed, so do not guarantee next-day pickup of an accessory solely from this table. Consult the relevant product catalogue if the customer uses an alias.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
