# Faulty arrival: replacement and evidence

Document ID: faults
Source: official
Effective: 2026-01-01 to open-ended
Related: warranty

When a fault was present on arrival and is reported within 90 calendar days after delivery, LumaHome offers a replacement at no charge, including a prepaid return label. This applies to standard, outlet, and personalized purchases. The customer must provide the order number and a photo or short video showing the fault. If that evidence has not yet been supplied, the next step is to request it; do not claim that a replacement is already approved.
Ordinary wear or accidental damage after delivery does not qualify under this policy. For a later manufacturing fault, consult the product warranty. Staff should distinguish requesting missing evidence from refusing coverage.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
