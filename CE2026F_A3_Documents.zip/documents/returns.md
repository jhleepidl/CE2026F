# Returns: standard purchases

Document ID: returns
Source: official
Effective: 2026-01-01 to open-ended
Related: outlet, personalized, faults

An unused standard item may be returned within 30 calendar days after delivery. A purchase record is required; an order number is sufficient, so a missing paper receipt does not remove eligibility. For a change-of-mind return, the customer pays a $6 return-label fee, deducted from the refund. Refunds go to the original payment method after inspection. A gift recipient may receive store credit instead; the purchase must still be traceable.
Exceptions are defined by the Outlet returns, Personalization, and Faulty arrival policies. Use the order record to identify whether an exception applies. Standard return wording must not override a more specific policy. The return window starts on delivery, not on the order date.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
