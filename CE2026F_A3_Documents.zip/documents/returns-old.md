# Returns: earlier sixty-day promotion

Document ID: returns-old
Source: official
Effective: 2026-01-01 to 2026-08-31
Related: 

During the summer promotion, unused standard purchases could be returned within 60 calendar days after delivery without a label fee. Outlet products had a 30-day window during the promotion. These promotional terms applied only through August 31, 2026 and have ended.
This archived page is kept for historical queries. For a current September question, consult the current returns and outlet pages. A keyword match on returns, label fee, or Halo does not make an expired promotion applicable. The dates in this record are part of its policy scope.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
