# Gift wrapping and message cards

Document ID: gift-wrap
Source: official
Effective: 2026-01-01 to open-ended
Related: personalized, returns

Gift wrapping is available for desk lamps and speakers for $3 per order. Gift messages are printed without prices. A message card is not product engraving and does not make an otherwise ordinary product personalized. Engraving is recorded separately on the order.
Wrapping fees are not returned for a change-of-mind return after wrapping has been completed. This page does not alter the product return window or faulty-arrival coverage. Staff should ask whether the product itself was personalized rather than inferring it from the presence of a gift message.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
