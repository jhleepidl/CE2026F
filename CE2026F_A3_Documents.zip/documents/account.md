# Changing contact details on an order

Document ID: account
Source: official
Effective: 2026-01-01 to open-ended
Related: 

Before dispatch, the order support team can process a request to update the contact email after identity verification. A new email address does not change the delivery address automatically. After dispatch, carrier-address changes depend on the carrier and are not guaranteed by this policy.
The document collection does not include identity-verification secrets. An assistant should explain the documented process rather than ask for a password or full card number. Updating contact details does not restart a return window or change an item's outlet classification.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
