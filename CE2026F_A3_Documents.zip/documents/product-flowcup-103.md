# FlowCup Series 103: coffee machine, identity and compatible basket

Document ID: product-flowcup-103
Source: official
Effective: 2026-01-01 to open-ended
Related: manual-flowcup-103, help-flowcup-103, warranty, stock

## Product identity and scope
FlowCup Series 103, SKU FL-103, is a coffee brewing unit in the FlowCup range. Retail descriptions may call it the coffee machine, but the model number on the rating label distinguishes it from earlier units. This entry applies only to Series 103. It does not describe the earlier LumaHome core models Halo Desk HD, Halo Wall HW, SteamDrop K1/K2, or PocketBeat Mini PB-M. A shared brand word is not a compatible-part specification. Colour editions use the same electrical platform unless the order says otherwise.
## Package and controls
The standard package contains the brewer, a quick-start sheet, and the basket identified as FL-103-P3. This generation supports brew volume; the remembered setting is 4 and the nominal package mass is 650 grams. Power is supplied through a fixed mains lead. A gift-wrap sleeve or handwritten message is packaging, not personalized engraving. Engraving must appear as a separate order field. Open-box stock has its own order classification and should not be mistaken for a different model generation.
## Compatibility
Replacement basket FL-103-P3 is approved for this exact generation. Part FL-104-P4 belongs to another series and is not an approved substitute. Similar dimensions, matching colour, or a connector that appears to fit do not establish compatibility. A customer without a readable model label should first provide the label details. Do not infer a replacement part from a photograph of the retail box alone, since boxes may have been reused for storage.
## Service classification
The manufacturing-fault warranty for this brewer is 12 months from delivery under the applicable regional terms. Ordinary wear, accidental damage, and undocumented third-party alterations need separate assessment. A reported arrival fault should be handled through the arrival-fault workflow rather than applying the unused-item return window. Product specifications do not say whether an individual customer's order is within a deadline. Read the order event and the relevant policy before explaining an entitlement.
## Distribution and availability
This product is sold as a mains-powered item without a rechargeable lithium battery; do not borrow transport restrictions from a different product category. Catalogue availability means that a product exists in the range. It does not establish current branch stock, a restock date, or whether an order has been dispatched. An estimated product launch week is not a carrier delivery commitment. Consult the shipping policy and live operational systems where those facts are required.
## Support references
The operating guide is manual-flowcup-103, and the symptom index is help-flowcup-103. Read them for a control or accessory question. For an individual purchase, find its order record separately. This page contains no identity-verification secret and no authority to issue a refund. A support response should identify the exact model and the applicable source, and omit specifications unrelated to the question.
