# Harbor pickup: October holiday closure

Document ID: holiday-future
Source: official
Effective: 2026-10-03 to 2026-10-03
Related: 

Harbor customer pickup will be closed on October 3, 2026. Ready orders may be collected on the next open day. This closure applies only on October 3; it must not be applied to a September collection request.
Normal identification and readiness requirements remain in force. The closed-day notice does not authorize using the supplier loading bay. A later publication date alone does not make a notice relevant to every question; match its effective dates and branch.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
