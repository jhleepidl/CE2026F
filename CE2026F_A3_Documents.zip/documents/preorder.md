# Preorders: payment and cancellation

Document ID: preorder
Source: official
Effective: 2026-01-01 to open-ended
Related: returns

A preorder takes a $10 reservation deposit when placed. The remaining balance is charged only when the item is dispatched. Before dispatch, a customer may cancel and receive the deposit back. After dispatch, use the applicable return policy rather than promising preorder cancellation.
A product's estimated release date is not a confirmed arrival date. A reservation confirmation is not a dispatch confirmation. Read the order status before telling a customer that the remaining balance has been charged. Promotional emails do not override the timing in this policy.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
