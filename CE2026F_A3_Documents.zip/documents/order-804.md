# Order LH-804: BreezeArc delivered

Document ID: order-804
Source: official
Effective: 2026-01-01 to open-ended
Related: returns

## Order identity
Order LH-804 contains BreezeArc Series 105, described in the shop as a tower fan. It belongs to customer account C-3204. This is a fictional transaction record for support lookup. The order identifier, rather than the product description, distinguishes it from other purchases of the same model. Product specifications belong to product-breezearc-105; this order is the source for the purchase channel and event history.
## Classification and fulfilment
The purchase channel is standard. Status is delivered. The requested service location is Willow Basin. The merchandise line has quantity 2; the order includes ordinary packaging and no gift message. Personalization is no. A gift message card should not be substituted for the personalization field. A stock item and a preorder may look identical in the current catalogue while having different payment events.
## Timeline
The order was placed on September 5, 2026. The last recorded fulfilment event is September 15, 2026. Where status is delivered, that event is delivery; where status is ready for collection, it is the ready email; where status is preorder, it is a reservation update and not dispatch. The order contains no later event. Do not invent a tracking update merely because several days have elapsed since this snapshot.
## Customer contact
The customer asks about returning an unused item. They can provide the order number. No technical assessment, approved exception, or completed refund is recorded. An agent's request for information is not approval of a requested remedy. Read the applicable policy before explaining a fee, deadline, or evidence requirement.
## Handoff notes
Keep the exact order number and event type in the case note. A matching product title is useful for catalogue lookup but cannot supply a delivery date. The branch requested on the order does not itself establish current opening hours. A dated branch notice must match both the branch and the intended visit date. Do not apply a notice for Harbor, Hill, or a similarly named location without checking its scope.
## Data limits
This record is a static snapshot and is not connected to payment, inventory, or carrier systems. It cannot confirm a refund posted today, a part available tomorrow, or a guaranteed arrival. The relevant policy links describe procedures; they do not certify completed actions. Another agent can use the source identifier to reconstruct the same decision without assuming that a later live lookup has already occurred.
