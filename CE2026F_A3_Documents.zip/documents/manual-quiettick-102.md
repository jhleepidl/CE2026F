# QuietTick Series 102: operating guide and alarm schedule

Document ID: manual-quiettick-102
Source: official
Effective: 2026-01-01 to open-ended
Related: product-quiettick-102, help-quiettick-102

## Coverage
This is the customer-support operating guide for QuietTick Series 102 (QU-102), a bedside time display. It covers identification, normal controls, and the information needed for a service handoff. It does not describe other QuietTick generations or authorize internal repairs. A document mentioning the same alarm clock may use different accessories. Compare the rating label with this guide before using a control name, reset sequence, or replacement-part identifier.
## Initial inspection
The customer should compare the supplied items with the package list in product-quiettick-102. Record whether the unit was newly delivered, previously working, or bought open-box. Those are different histories even when the current symptom sounds the same. If the box is damaged, retain the delivery packaging while support records the report. Never treat the absence of retail packaging as proof that a manufacturing fault is excluded; consult the applicable policy for evidence requirements.
## Normal controls
The alarm schedule feature has 4 selectable positions. The display indicator labelled M2 shows a saved preference rather than a warranty status. A return to the default setting changes the preference only; it does not update an order, restore an account, or confirm that the hardware is working. The illustrated names refer to the customer controls, not internal components. A light changing colour is not a substitute for a written diagnostic result.
## Accessory identification
The serviceable external accessory is stand QU-102-P2. Keep this code with the model number when requesting an availability check. Components listed for another Series 103 unit are not automatically interchangeable. The support catalogue establishes compatible identifiers but contains no warehouse quantity. If a customer asks whether an accessory can be collected tomorrow, consult an inventory system before promising a reservation or pickup time.
## Care and service boundaries
Follow the safety leaflet supplied with the actual unit. This help-desk document does not instruct a customer to open a housing, bypass a control, or use an unapproved power supply. If there is damage or unexpected heating, stop the ordinary troubleshooting conversation and route the report to the product-support team. Avoid diagnosing the cause from a single description. Record what was observed, when it began, and whether the unit ever worked normally.
## Handoff and evidence
The symptom reference help-quiettick-102 lists the information support needs. Include the exact model, relevant accessory code, order number, and the chronology of the problem. A photo of a label may establish model identity; it does not establish when delivery occurred. An order receipt establishes purchase details but not the physical cause of a fault. Keep these evidence roles separate when preparing a reply. Customer-facing instructions should cover the next documented step instead of repeating every section of this guide.
