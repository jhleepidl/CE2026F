# Personalization and engraved items

Document ID: personalized
Source: official
Effective: 2026-01-01 to open-ended
Related: faults, returns

An item engraved or printed to a customer's specification cannot be returned for a change of mind, even if unused and still within 30 days. A gift does not create an exception. An unused ordinary gift item may follow the standard policy, but custom engraving makes it a personalized item.
Personalized goods that arrived faulty are covered by the Faulty arrival policy. A defect is not the same as a spelling choice that the customer approved. Agents must use the order's personalization field. Do not infer engraving merely because the product model supports engraving.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
