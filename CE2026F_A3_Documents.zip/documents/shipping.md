# Shipping destinations and lithium batteries

Document ID: shipping
Source: official
Effective: 2026-01-01 to open-ended
Related: catalog-audio

Standard non-battery products can be shipped within the country and to the Island region. PocketBeat speakers contain a lithium battery; the Island air route does not accept these speakers. The restriction applies to gifts, replacements, and ordinary orders alike. Do not infer that an item can travel by air merely because it is small.
Mainland ground delivery accepts PocketBeat speakers. The catalogue identifies battery-containing products. Kettles and lamps without batteries do not inherit the speaker restriction. This policy does not list delivery dates for a specific order; use a shipment record for any arrival-date commitment.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
