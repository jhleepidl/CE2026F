# Outlet returns: clearance and open-box purchases

Document ID: outlet
Source: official
Effective: 2026-01-01 to open-ended
Related: faults

Outlet purchases include clearance and open-box items. Unused outlet items may be returned within 14 calendar days after delivery, with an order number. The customer pays the $6 label fee for a change-of-mind return. Day 14 is included; day 15 is too late. This shorter window replaces the standard 30-day window, even when the model is also sold at full price. The purchase channel on the order record controls eligibility, not the current catalogue price.
An item that arrived faulty follows the Faulty arrival policy instead of this change-of-mind limit. Do not ask a customer to pay the change-of-mind fee for a documented faulty arrival.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
