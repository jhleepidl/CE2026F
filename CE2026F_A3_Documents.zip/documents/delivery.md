# Delivery estimates and tracking

Document ID: delivery
Source: official
Effective: 2026-01-01 to open-ended
Related: preorder, stock

Mainland standard delivery normally takes three to five business days after dispatch. This is an estimate, not an order-specific promise. A dispatch confirmation includes the carrier tracking reference. Preorder release estimates are not dispatch dates.
If an order has not been dispatched, do not apply the transit estimate as if it were already travelling. This collection contains no live carrier tracking feed. Requests for a guaranteed arrival tomorrow require information beyond a normal delivery estimate. A customer may select pickup before dispatch if the order system offers it, but support must not invent branch stock.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
