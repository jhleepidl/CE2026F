# Product warranty: manufacturing faults after arrival

Document ID: warranty
Source: official
Effective: 2026-01-01 to open-ended
Related: faults, catalog-light

LumaHome branded lamps and kettles have a 12-month manufacturing-fault warranty from delivery. PocketBeat speakers have a 6-month warranty. Accidental damage and ordinary battery wear are excluded. Warranty handling requires the order number and a description of the fault. For an installed hardwired lamp, installation must have been performed by a licensed electrician and the installation receipt must be available.
The warranty does not set the ordinary change-of-mind return period. An order described as faulty on arrival should be assessed under the Faulty arrival policy first. This document does not promise a replacement for an excluded accident.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
