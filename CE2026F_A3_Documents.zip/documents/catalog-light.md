# Halo lamp: desk and hardwired variants

Document ID: catalog-light
Source: official
Effective: 2026-01-01 to open-ended
Related: warranty, personalized

Halo Desk, code HD, is a plug-in desk lamp. Halo Wall, code HW, is a hardwired wall lamp; its installation requires a licensed electrician for warranty eligibility. Both variants support optional engraving, but only an order marked personalized has actually been engraved.
The catalogue does not say whether an individual customer's electrician was licensed or whether a receipt is available. Consult the order and the customer's stated installation facts. A desk lamp does not require an installation receipt. Both variants have the 12-month manufacturing-fault warranty, subject to its conditions.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
