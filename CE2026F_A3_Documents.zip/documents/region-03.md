# Amber Plains reseller returns and collection

Document ID: region-03
Source: official
Effective: 2026-01-01 to open-ended
Related: returns, pickup

## Jurisdiction and contract
This service schedule applies only to purchases explicitly made under the Amber Plains regional reseller contract. It does not replace the general LumaHome shop terms for a customer whose order has no regional contract. The reseller remains the source for transaction-specific approvals. Product names such as Halo, SteamDrop, and PocketBeat can appear in several regions with different contract conditions. Match the named contract before selecting a policy from a similarity search.
## Unused-item requests
Under this schedule, an unused ordinary item can be returned within 21 calendar days after delivery. A change-of-mind label costs $7. Outlet classification and personalized orders still require the reseller's specific exception schedule. The region's unused-item deadline is not a warranty period and does not settle a fault-on-arrival claim. An order number can establish the transaction when the original paper receipt is unavailable; it does not extend a deadline.
## Evidence and processing
The reseller needs the order identifier, delivery event, stated reason, and purchase classification. Record whether the customer reports a physical fault, a missing accessory, or a colour preference. A customer describing a problem as a defect does not complete an assessment. If a photo or video is required, request that evidence without asserting that a remedy has already been approved. A request submitted before a deadline and a parcel inspected later are separate events.
## Collection arrangements
The Amber Plains service point offers collection between 9:00 and 16:00 on its published open days. A ready notice and identity check remain necessary. These hours apply to the regional service point, not to the Harbor or Hill retail branches. Temporary notices can narrow the hours on particular dates. Supplier access arrangements are not customer pickup permissions, and an order cannot be moved between locations by changing a reply's wording.
## Payments and limits
Refund processing follows the original payment route after acceptance and inspection. This document provides no individual payment ledger, points balance, live inventory feed, or guaranteed restock date. A regional catalogue listing does not reserve a product. For preorders, read the applicable reservation event before treating an estimated release date as dispatch. Staff should leave missing operational facts unresolved rather than borrowing an apparently plausible event from another customer's record.
## Version control
This current schedule is effective only during the dates in its metadata. Earlier promotional wording may remain searchable for historical requests but must not be applied outside its period. A support handoff should record the regional contract, policy version, and event used for the decision. Where the customer has not identified a regional contract, use the general shop documents and do not select the most generous schedule simply because it offers a favourable outcome.
