# Repairs and service appointments

Document ID: repair
Source: official
Effective: 2026-01-01 to open-ended
Related: warranty

Warranty support begins with an order number and a fault description. The service team confirms eligibility and then offers an appointment or shipping instructions. This general workflow does not change product-specific warranty periods, exclusions, or installation requirements.
No live appointment calendar is included here. Support cannot promise an exact repair date from this document. Never tell a customer to open a hardwired appliance or perform an electrical repair. For an installed Halo Wall lamp, the warranty page identifies the licensed-installation documentation that support needs.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
