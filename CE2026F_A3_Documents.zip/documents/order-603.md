# Order LH-603: Harbor collection readiness

Document ID: order-603
Source: official
Effective: 2026-01-01 to open-ended
Related: pickup, harbor-notice

Order LH-603 contains a SteamDrop K2 kettle. Pickup branch: Harbor. A ready-for-collection email was sent September 23, 2026. The named buyer has the order number and photo ID. The order has not yet been collected.
The record confirms readiness and the chosen branch, but not the opening hours for every date. Consult both the pickup procedure and any branch notice effective on the requested collection date. A maintenance notice does not cancel the order or move it automatically to another branch.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
