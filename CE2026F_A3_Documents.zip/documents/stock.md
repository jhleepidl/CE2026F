# Inventory information: limits of this document collection

Document ID: stock
Source: official
Effective: 2026-01-01 to open-ended
Related: 

This document collection contains product specifications and selected order records, but no live stock feed. It does not establish today's quantity, tomorrow's availability, or a restock date for any product or replacement part. A listed model may be sold out. A catalogue entry is not evidence of inventory.
When a question requires a stock commitment, say that the available documents do not establish it. Staff would need an inventory lookup outside this exercise before making the commitment. Do not turn an old sales announcement, a customer guess, or the existence of an accessory into a stock guarantee.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
