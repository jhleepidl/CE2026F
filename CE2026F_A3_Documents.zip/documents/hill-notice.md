# Hill pickup: weekend counter location

Document ID: hill-notice
Source: official
Effective: 2026-01-01 to open-ended
Related: 

Hill's customer pickup desk operates from 10:00 to 19:00. On Saturdays the desk moves to the indoor service counter, but the opening hours stay the same. A ready-for-collection email, order number, and photo ID are still required. The Harbor maintenance notice does not affect Hill.
There is no courier handoff at the indoor counter. Staff may help a customer locate the correct order confirmation, but cannot release a parcel solely from a payment screenshot. An authorized collecting adult follows the same written-authorization rule as at the usual desk.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
