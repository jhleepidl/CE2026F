# Harbor pickup: maintenance notice, September 24–26

Document ID: harbor-notice
Source: official
Effective: 2026-09-24 to 2026-09-26
Related: 

From September 24 through September 26, 2026, Harbor's customer pickup desk opens at 12:00 and closes at 16:00 because of maintenance. The normal 09:00–18:00 hours do not apply on these dates. Orders already marked ready remain available during the temporary hours.
The rear loading bay is for scheduled supplier deliveries only. It is not an alternative customer collection point. Customer-support agents should offer collection during the temporary hours; they must not promise access through the loading bay. Hill's pickup hours are unchanged by this Harbor notice.
## Applying this page
Check the page's scope and effective dates before using its wording in a reply. A similar title can describe a different product generation, branch, region, or archived campaign. Read linked source records when this procedure depends on a purchase classification or another event. Give the customer the applicable next step and avoid extending a documented exception to unrelated situations. Keep the distinction between a rule and a live operational fact visible.
## Support handoff
Record the source identifier used for the decision so another support worker can find the same page. Quote only the necessary condition in a customer reply; reproducing the entire manual rarely helps. Escalate a missing fact to the relevant system instead of filling it with an estimate. This static knowledge archive cannot confirm a live inventory balance, a new dispatch event, or completion of a refund. A related page may clarify scope but must still be read before it is used as evidence.
