# Order LH-482: Halo Desk outlet purchase

Document ID: order-482
Source: official
Effective: 2026-01-01 to open-ended
Related: outlet

Order LH-482 belongs to Dana Reed. Product: Halo Desk HD. Purchase channel: outlet, open-box. Delivered September 6, 2026. The order is not personalized. The recorded reason for contact is a change of mind; the customer reports that it is unused and working normally. The order number is available, but the paper receipt is missing.
Use the outlet return window for this purchase even though Halo Desk is also sold through the standard shop. This record contains no report of an arrival fault. The presence of the order number satisfies purchase-record lookup; it does not lengthen the return window.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
