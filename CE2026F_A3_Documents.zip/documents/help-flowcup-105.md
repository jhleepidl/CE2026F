# FlowCup Series 105: intermittent operation

Document ID: help-flowcup-105
Source: official
Effective: 2026-01-01 to open-ended
Related: product-flowcup-105, manual-flowcup-105, faults

## Report category
This support article concerns FlowCup Series 105 (FL-105) reports described as "intermittent operation". The phrase is a symptom category, not a confirmed diagnosis. Several products in the FlowCup range can produce similar customer descriptions. Establish the model identifier before selecting this page. Do not apply this article to an earlier core model merely because a search for coffee machine returns it near the top.
## Questions that distinguish cases
Ask whether the product behaved this way on first opening or after a period of ordinary use. Record whether the relevant basket is original, replaced, or unknown. Ask the customer to read the label rather than infer a model from colour. A gift recipient may not have the paper receipt but can still have a traceable order number. These facts decide which policy or product guide to consult; they do not by themselves approve a replacement.
## Documented control behaviour
The brew volume setting belongs to the Series 105 interface. The expected accessory identifier is FL-105-P5, and status marker M5 refers to that generation. If the customer's description names a different identifier, compare the product catalogue before discussing operation. A nearby generation can have a similar display while using a different part. The operating guide manual-flowcup-105 is the appropriate source for normal customer controls.
## Evidence needed for a service request
For an arrival-fault claim, obtain the order number and the photo or short video required by the applicable fault policy. A message that a product is faulty is the customer's report, not a completed technical assessment. If evidence has not been supplied, explain the missing step without asserting that coverage has been refused. The passage of an unused-item return window does not settle whether a manufacturing-fault request has a separate remedy.
## Wrong turns to avoid
Do not turn a compatible-part listing into a stock guarantee. Do not transfer warranty wording from a different product generation, country, or sales contract. Do not interpret a saved setting as proof that a fault has been fixed. Never mark a payment or replacement complete based only on a draft support response. These mistakes combine facts from different sources without establishing the necessary relationship.
## Escalation note
A useful handoff states the order and model identifiers, the reported symptom, its timing, the available evidence, and the document still needed. It does not include passwords, full payment-card details, or invented warehouse quantities. Use product-flowcup-105 to verify identity and manual-flowcup-105 to verify the control description. If a necessary event or observation is absent, leave it explicitly unresolved for the next operational lookup.
