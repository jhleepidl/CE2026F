# Order LH-517: engraved PocketBeat gift

Document ID: order-517
Source: official
Effective: 2026-01-01 to open-ended
Related: personalized, faults

Order LH-517 is a PocketBeat Mini speaker engraved with initials and sold as a gift. Delivered September 19, 2026. Purchase channel: standard. Personalization: yes. The customer reports that it would not power on when first opened. The order number has been provided, but no photo or video of the fault has been submitted.
This record does not approve a replacement. It records the customer's report for support assessment. Consult both the personalization exception and the faulty-arrival requirements. The recipient has not described accidental damage after delivery.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
