# Order LH-705: reserved Halo Desk preorder

Document ID: order-705
Source: official
Effective: 2026-01-01 to open-ended
Related: preorder

Order LH-705 reserves a new Halo Desk finish. Status: preorder, not dispatched. The reservation deposit has been paid. The customer asks whether cancellation now returns the deposit and whether the remaining balance should already have been charged.
No dispatch event has been recorded. The expected release week is an estimate only. Consult the preorder policy for payment timing and cancellation. This record should not be interpreted as a regular delivered order simply because an order number exists.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
