# Order LH-644: Halo Wall installation record

Document ID: order-644
Source: official
Effective: 2026-01-01 to open-ended
Related: catalog-light, warranty

Order LH-644 is a Halo Wall HW lamp delivered March 20, 2026. A manufacturing fault is reported on September 24. The customer says that a licensed electrician installed it and that the installation receipt is available. The order number and fault description are available. No accidental damage is reported.
The lamp was not faulty on arrival. Evaluate this as a later warranty request. This record does not make every installed product eligible; apply the product's warranty period and the installation conditions. An ordinary return window is not the relevant deadline for this request.
## Record use and handoff
Read the delivery event, purchase channel, personalization field, and reported condition together. A current product advertisement cannot change an earlier purchase classification. The order identifier is the join key for the support conversation; names and product descriptions alone can match several purchases. Keep the original delivery date visible when calculating a deadline, and distinguish the date the customer wrote to support from the date the item arrived.
## Follow-up record
A later agent should be able to see which fact came from the order and which rule came from the policy. Link the applicable policy version rather than copying an unexplained entitlement into the order notes. If a necessary event has not been recorded, describe it as missing; a request to cancel is not a completed cancellation. The public links attached to this record are document references, not confirmation that a requested action has already happened.
