# LumaHome Support Archive v2

430 English fictional support documents: product catalogues, operating manuals, troubleshooting articles, order snapshots, general policies, and current/archived regional contracts.

`documents.jsonl` is the canonical import file. Each record contains id, title, text, source, valid_from, valid_to, related, and category. `documents/` provides individually readable Markdown copies. `manifest.json` records version, counts, token statistics, and the canonical file hash.

All content is original fictional course data, dedicated under CC0 1.0. It is not real product, repair, contractual, or customer information. No answer keys, grading labels, API keys, embeddings, or executable code are included. Questions and evaluation remain in the notebook.

Scope matters: a model family is not a model number; a regional reseller policy is not a general shop policy; an archived campaign is not a current entitlement. Similar documents intentionally describe different objects and periods. The archive has no live inventory or carrier feed.
